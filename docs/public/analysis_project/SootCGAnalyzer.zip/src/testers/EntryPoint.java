package testers;

import android.telephony.TelephonyManager;
import com.android.internal.telephony.internally_generated.ITelephony;
import com.android.phone.PhoneInterfaceManager;
import android.content.Context;
import com.android.server.os.DeviceIdentifiersPolicyService;

public class EntryPoint
{
	public static void main(String[] args) {
		//invokeAPI();
		//invokeRemoteInterface_imei();
		invokeRemoteInterface_serial();
	}
	
	public static void invokeAPI() {
		Context context = null;
		TelephonyManager tm = new TelephonyManager();
		tm.getImei();
	}
	
	public static void invokeRemoteInterface_serial() {
		String callingPackage = "";
		String callingFeatureId = "";
		DeviceIdentifiersPolicyService.DeviceIdentifiersPolicy policy = new DeviceIdentifiersPolicyService.DeviceIdentifiersPolicy(null);
		policy.getSerialForPackage(callingPackage, callingFeatureId);
	}
	
	public static void invokeRemoteInterface_imei() {
		String callingPackage = "";
		String callingFeatureId = "";
		
		PhoneInterfaceManager pim = new PhoneInterfaceManager();
		pim.getImeiForSlot(0, callingPackage, callingFeatureId);
	}
}

