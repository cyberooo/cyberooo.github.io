/*
 * This file is auto-generated.  DO NOT MODIFY.
 */
package com.android.internal.telephony.internally_generated;

import android.os.IBinder;

/**
 * Interface used to interact with the phone. Mostly this is used by the
 * TelephonyManager class. A few places are still using this directly. Please
 * clean them up if possible and use TelephonyManager instead.
 * 
 * {@hide}
 */
public interface ITelephony extends android.os.IInterface {
	/** Default implementation for ITelephony. */
	public static class Default implements
			com.android.internal.telephony.internally_generated.ITelephony {
		// line 1338
		@Override
		public java.lang.String getImeiForSlot(int slotIndex,
				java.lang.String callingPackage,
				java.lang.String callingFeatureId) {
			return null;
		}

		@Override
		public IBinder asBinder() {
			// TODO Auto-generated method stub
			return null;
		}
	}

	/** Local-side IPC implementation stub class. */
	public static abstract class Stub extends android.os.Binder implements
			com.android.internal.telephony.internally_generated.ITelephony {
		/** Construct the stub at attach it to the interface. */
		public Stub() {
			// this.attachInterface(this, DESCRIPTOR);
		}

	    static final int TRANSACTION_getImeiForSlot = (android.os.IBinder.FIRST_CALL_TRANSACTION + 145);
	    
		/**
		 * Cast an IBinder object into an
		 * com.android.internal.telephony.ITelephony interface, generating a
		 * proxy if needed.
		 */
	    /*
		public static com.android.internal.telephony.internally_generated.ITelephony asInterface(
				android.os.IBinder obj) {

			if ((obj == null)) {
				return null;
			}
			android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
			if (((iin != null) && (iin instanceof com.android.internal.telephony.internally_generated.ITelephony))) {
				return ((com.android.internal.telephony.internally_generated.ITelephony) iin);
			}
			return new com.android.internal.telephony.internally_generated.ITelephony.Stub.Proxy(
					obj);
		}
		*/
		@Override
		public android.os.IBinder asBinder() {
			return this;
		}
		/*
		public static class Proxy implements
				com.android.internal.telephony.internally_generated.ITelephony {
			private android.os.IBinder mRemote;

			public Proxy(android.os.IBinder remote) {
				mRemote = remote;
			}

			@Override
			public android.os.IBinder asBinder() {
				return mRemote;
			}

			public java.lang.String getInterfaceDescriptor() {
				return DESCRIPTOR;
			}

			@Override
			public String getImeiForSlot(int slotIndex, String callingPackage,
					String callingFeatureId) {
				// TODO Auto-generated method stub
				
			        android.os.Parcel _data = android.os.Parcel.obtain();
			        android.os.Parcel _reply = android.os.Parcel.obtain();
			        java.lang.String _result;
			        try {
			          _data.writeInterfaceToken(DESCRIPTOR);
			          _data.writeInt(slotIndex);
			          _data.writeString(callingPackage);
			          _data.writeString(callingFeatureId);
			          boolean _status = mRemote.transact(Stub.TRANSACTION_getImeiForSlot, _data, _reply, 0);
			          _reply.readException();
			          _result = _reply.readString();
			        }
			        finally {
			          _reply.recycle();
			          _data.recycle();
			        }
			        return _result;
			      
				
			}
		}
		*/

		public static final java.lang.String DESCRIPTOR = "com.android.internal.telephony.ITelephony";
	}
	
	/**
	   * Returns the IMEI for the given slot.
	   * 
	   * @param slotIndex - device slot.
	   * @param callingPackage The package making the call.
	   * @param callingFeatureId The feature in the package
	   * <p>Requires Permission:
	   *   {@link android.Manifest.permission#READ_PHONE_STATE READ_PHONE_STATE}
	   */
	  public java.lang.String getImeiForSlot(int slotIndex, java.lang.String callingPackage, java.lang.String callingFeatureId) throws Exception;
	  
}