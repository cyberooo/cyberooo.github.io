package android.content;

public class Context{
	public Context(){
	}
}