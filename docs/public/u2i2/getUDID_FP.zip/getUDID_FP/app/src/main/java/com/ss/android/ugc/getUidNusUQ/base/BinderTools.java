package com.ss.android.ugc.getUidNusUQ.base;

import android.os.IBinder;
import android.os.Parcel;
import android.util.Log;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.util.HashMap;

public class BinderTools {
    public static int INTERFACE_TRANSACTION = ('_' << 24) | ('N' << 16) | ('T' << 8) | 'F';
    public static HashMap<String, String> allServices = new HashMap<>();

    public static String getInterfaceName(IBinder serHandle) {
        try {
            Parcel data = Parcel.obtain();
            Parcel reply = Parcel.obtain();
            serHandle.transact(INTERFACE_TRANSACTION, data, reply, 0);
            String interfacename = reply.readString();
            data.recycle();
            reply.recycle();
            return interfacename;
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public static String getTheInterfaceDescriptor(String servicename) {
        IBinder iBinder = getTheIbinder(servicename);
        if (iBinder == null) {
            return "";
        }
        String result = "";
        try {
            result = iBinder.getInterfaceDescriptor();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    public static int getCODE(String interfaceName, String fieldName) {
        try {
            Class clstub = Class.forName(interfaceName + "$Stub");
            Field field = clstub.getDeclaredField(fieldName);//"TRANSACTION_freeStorage"
            field.setAccessible(true);
            int val = field.getInt(null);
            return val;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }


    public static IBinder getTheIbinder(String name) {
        IBinder iBinder = null;
        try {
            iBinder = (IBinder) Class.forName("android.os.ServiceManager").getMethod("getService", String.class).invoke(null, name);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return iBinder;
    }


    public static String[] getAllServices() {
        String[] result = null;
        try {
            result = (String[]) Class.forName("android.os.ServiceManager").getMethod("listServices").invoke(null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        for (int i = 0; i < result.length; i++) {
            Log.e("privacyUDID", result[i]);
            String interFaceName = getTheInterfaceDescriptor(result[i]);
            if (interFaceName == null || interFaceName.equalsIgnoreCase("")) {
                if (getInterfaceName(getTheIbinder(result[i])) != null) {
                    if (!getInterfaceName(getTheIbinder(result[i])).equalsIgnoreCase("")) {
                        interFaceName = getInterfaceName(getTheIbinder(result[i]));
                    }
                }
            }
            if (interFaceName.equalsIgnoreCase("")) {
                interFaceName = "null";
            }
        }
        return result;
    }


    public static void getFinalServices(HashMap<String, String> hashMap) {
        String[] result = null;
        try {
            result = (String[]) Class.forName("android.os.ServiceManager").getMethod("listServices").invoke(null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        for (int i = 0; i < result.length; i++) {
            String interFaceName = getTheInterfaceDescriptor(result[i]);
            if (interFaceName == null || interFaceName.equalsIgnoreCase("")) {
                if (getInterfaceName(getTheIbinder(result[i])) != null) {
                    if (!getInterfaceName(getTheIbinder(result[i])).equalsIgnoreCase("")) {
                        interFaceName = getInterfaceName(getTheIbinder(result[i]));
                    }
                }
            }
            if (interFaceName.equalsIgnoreCase("")) {
                interFaceName = "null";
            }
            if (!hashMap.containsKey(result[i])) {
                hashMap.put(result[i], interFaceName);
            } else {
                String val = hashMap.get(result[i]);
                if (val.equalsIgnoreCase("null"))
                    hashMap.put(result[i], interFaceName);
            }
        }
    }

    public static void getBinderServicesByCmd(HashMap<String, String> hashMap) {
        Process process = null;
        BufferedReader bufferedReader = null;
        StringBuilder mShellCommandSB = new StringBuilder();
        mShellCommandSB.delete(0, mShellCommandSB.length());
        String[] cmd = new String[]{"/system/bin/sh", "-c", "service list"}; //调用bin文件
        try {
            byte b[] = new byte[1024];
            process = Runtime.getRuntime().exec(cmd);
            bufferedReader = new BufferedReader(new InputStreamReader(
                    process.getInputStream()));
            String line;

            while ((line = bufferedReader.readLine()) != null) {
                mShellCommandSB.append(line);
                Log.e("privacyUDID", line);
                if (!line.startsWith("Found ")) {
                    String[] result = line.split("\t");
                    result = result[1].split(":");
                    String key = result[0];
                    result = result[1].split("\\[");
                    String val = result[1];
                    if (val.length() != 1) {
                        val = val.substring(0, val.length() - 1);
                    } else {
                        val = "null";
                    }
                    //Log.e("privacyUDID",key+" "+val);
                    hashMap.put(key, val);
                }
            }
            process.waitFor();
            bufferedReader.close();
            process.destroy();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void writeIn(String file, String content) {
        try {
            FileWriter writer = new FileWriter(file, true);
            writer.write(content);
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
