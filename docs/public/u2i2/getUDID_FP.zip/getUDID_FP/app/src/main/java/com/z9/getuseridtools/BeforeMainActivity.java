package com.z9.getuseridtools;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class BeforeMainActivity extends Activity {

    private final static int ACCESS_COARSE_LOCATION = 101;
    private final static int WRITE_EXTERNAL_STORAGE_CODE = 102;
    private final static int READ_PHONE_STATE = 103;
    private final static int RECEIVE_SMS = 104;
    private final static int WRITE_CONTACTS = 105;
    private final static int READ_CONTACTS = 106;
    private final static int CALL_PHONE = 107;
    private final static int ACCESS_FINE_LOCATION = 108;
    private final static int CALL_LOG = 109;
    private final static int WRITE_CALL_LOG = 110;
    private final static int RECORD_AUDIO = 111;
    private final static int READ_PHONE_NUMBERS = 112;
    private final static int READ_SMS = 113;
    public static PermissionModel[] models = new PermissionModel[]{
            new PermissionModel(Manifest.permission.ACCESS_COARSE_LOCATION, "1", ACCESS_COARSE_LOCATION),
            new PermissionModel(Manifest.permission.READ_PHONE_STATE, "2", READ_PHONE_STATE),
            new PermissionModel(Manifest.permission.READ_PHONE_NUMBERS, "3", READ_PHONE_NUMBERS),
            new PermissionModel(Manifest.permission.WRITE_EXTERNAL_STORAGE, "4", WRITE_EXTERNAL_STORAGE_CODE),
            new PermissionModel(Manifest.permission.RECEIVE_SMS, "4", RECEIVE_SMS),
            new PermissionModel(Manifest.permission.READ_SMS, "5", READ_SMS),
            new PermissionModel(Manifest.permission.WRITE_CONTACTS, "6", WRITE_CONTACTS),
            new PermissionModel(Manifest.permission.READ_CONTACTS, "6", READ_CONTACTS),
            new PermissionModel(Manifest.permission.CALL_PHONE, "6", CALL_PHONE),
            new PermissionModel(Manifest.permission.READ_CALL_LOG, "6", CALL_LOG),
            new PermissionModel(Manifest.permission.ACCESS_FINE_LOCATION, "GPS", ACCESS_FINE_LOCATION),
            new PermissionModel(Manifest.permission.RECORD_AUDIO, "Audio", RECORD_AUDIO)
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT < 23) {
            openDemo();
            return;
        }
        checkPermissions();
    }

    private void openDemo() {
        Intent intent=new Intent();
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setClass(this,MainActivity.class);
        getApplicationContext().startActivity(intent);
        this.finish();
    }

    private void checkPermissions() {
        try {
            for (PermissionModel model : models) {
                if (PackageManager.PERMISSION_GRANTED != ContextCompat.checkSelfPermission(this, model.permission)) {
                    ActivityCompat.requestPermissions(this, new String[]{model.permission}, model.requestCode);
                    return;
                }
            }
            openDemo();
        } catch (Throwable e) {
            Log.e("gxfc", "", e);
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case READ_PHONE_STATE:
            case ACCESS_COARSE_LOCATION:
                if (PackageManager.PERMISSION_GRANTED != grantResults[0]) {

                    if (ActivityCompat.shouldShowRequestPermissionRationale(this, permissions[0])) {
                    }
                    else {
                        Toast.makeText(this, "permission deny", Toast.LENGTH_LONG).show();
                        openAppPermissionSetting(123456789);
                    }
                }
                break;
            default:
                break;
        }
        if (isAllRequestedPermissionGranted()) {
            //Log.e("privacyUDID", "all");
            openDemo();
        } else {
            checkPermissions();
        }
    }

    private String findPermissionExplain(String permission) {
        if (models != null) {
            for (PermissionModel model : models) {
                if (model != null && model.permission != null && model.permission.equals(permission)) {
                    return model.explain;
                }
            }
        }
        return null;
    }

    private boolean isAllRequestedPermissionGranted() {
        for (final PermissionModel model : models) {
            if (PackageManager.PERMISSION_GRANTED != ContextCompat.checkSelfPermission(this, model.permission)) {
                return false;
            }
        }
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {

            case 123456789:
                if (isAllRequestedPermissionGranted()) {
                    openDemo();
                } else {
                    Toast.makeText(this, "exit", Toast.LENGTH_LONG).show();
                    this.finish();
                }
                break;
            default:
                super.onActivityResult(requestCode, resultCode, data);
        }
    }

    private boolean openAppPermissionSetting(int requestCode) {
        try {
            Intent intent =
                    new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + this.getPackageName()));
            intent.addCategory(Intent.CATEGORY_DEFAULT);


            startActivityForResult(intent, requestCode);
            return true;
        } catch (Throwable e) {
            Log.e("gxfc", "", e);
        }
        return false;
    }

    public static class PermissionModel {
        /**
         */
        public String permission;
        /**
         */
        public String explain;
        /**
         */
        public int requestCode;

        public PermissionModel(String permission, String explain, int requestCode) {
            this.permission = permission;
            this.explain = explain;
            this.requestCode = requestCode;
        }
    }
}
