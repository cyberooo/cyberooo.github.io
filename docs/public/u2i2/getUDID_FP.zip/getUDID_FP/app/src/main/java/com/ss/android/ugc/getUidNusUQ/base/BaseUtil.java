package com.ss.android.ugc.getUidNusUQ.base;
import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.util.Base64;
import android.util.Log;

import com.z9.getuseridtools.MyApplication;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.MessageDigest;
import java.util.ArrayList;

public class BaseUtil {
    public static String runCmd(String[] args) {
        String result = "";
        ProcessBuilder cmd;
        InputStream in = null;
        try {
            cmd = new ProcessBuilder(args);
            Process process = cmd.start();
            in = process.getInputStream();
            byte[] re = new byte[1024];
            while (in.read(re) != -1) {
                result = result + new String(re)+"\n";
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            result = "N/A";
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return result.trim();
    }
    public static ArrayList readIn(String filePath) {
        ArrayList<String> arrayList=new ArrayList<>();
        try {
            BufferedReader bufr = new BufferedReader(new FileReader(filePath));
            String line = null;
            while ((line = bufr.readLine()) != null) {
                arrayList.add(line);
                //Log.e("privacyUDID",line);
            }
            //arrayList.remove(arrayList.size()-1);
            bufr.close();
        } catch (Exception e) {
            e.printStackTrace();// TODO: handle exception
        }
        return arrayList;
    }
    public static String readFile(String str) {
        File file = new File(str);
        StringBuilder sb = new StringBuilder();
        FileInputStream fileInputStream = null;
        BufferedReader bufferedReader = null;
        if (file.exists()) {
            try {
                String line;
                fileInputStream = new FileInputStream(file);
                bufferedReader = new BufferedReader(new InputStreamReader(fileInputStream));
                while ((line = bufferedReader.readLine()) != null) {
                    sb.append(line);
                }
                return sb.toString();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (bufferedReader != null) {
                    try {
                        bufferedReader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                if (fileInputStream != null) {
                    try {
                        fileInputStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return "";
    }
    public static boolean isExecutable(String filePath) {
        Process p = null;
        try {
            p = Runtime.getRuntime().exec("ls -l " + filePath);
            BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String str = in.readLine();
            Log.e("privacyUDID", str);
            if (str != null && str.length() >= 4) {
                char flag = str.charAt(3);
                if (flag == 's' || flag == 'x')
                    return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (p != null) {
                p.destroy();
            }
        }
        return false;
    }
    public static String getCurrentProcessName(Context context) {
        if (context == null) {
            return null;
        }
        try {
            String currentProcessName = "";
            int pid = android.os.Process.myPid();
            int uid = android.os.Process.myUid();
            Log.e("privacyUDID", "pid" + pid + "  uid:" + uid);
            ActivityManager manager = (ActivityManager) context.getApplicationContext()
                    .getSystemService(Context.ACTIVITY_SERVICE);
            for (ActivityManager.RunningAppProcessInfo processInfo : manager.getRunningAppProcesses()) {
                if (processInfo.pid == pid) {
                    currentProcessName = processInfo.processName;
                    break;
                }
            }
            return currentProcessName;
        } catch (Exception e) {
            return null;
        }
    }

    public static void runShellCommand(String command) {
        BaseUtil.writeIn("/sdcard/bindertest/"+ MyApplication.packageName+".txt", "\n\n" + "runShellCommand start---"+command);
        Process process = null;
        BufferedReader bufferedReader = null;
        StringBuilder mShellCommandSB = new StringBuilder();
        Log.e("privacyUDID", "runShellCommand :" + command);
        mShellCommandSB.delete(0, mShellCommandSB.length());
        String[] cmd = new String[]{"/system/bin/sh", "-c", command};
        try {
            byte b[] = new byte[1024];
            process = Runtime.getRuntime().exec(cmd);
            bufferedReader = new BufferedReader(new InputStreamReader(
                    process.getInputStream()));
            String line;

            while ((line = bufferedReader.readLine()) != null) {
                mShellCommandSB.append(line);
                Log.e("privacyUDID",line);
                BaseUtil.writeIn("/sdcard/bindertest/"+MyApplication.packageName+".txt", "\n" + line);

            }
            Log.e("privacyUDID", "runShellCommand result : " + mShellCommandSB.toString());
            process.waitFor();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (bufferedReader != null) {
                try {
                    bufferedReader.close();
                } catch (Exception e) {
                    // TODO: handle exception
                }
            }

            if (process != null) {
                process.destroy();
            }
        }
    }
    public static void writeIn(String file, String content) {
        try {
            FileWriter writer = new FileWriter(file, true);
            writer.write(content);
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static String checkAppSignature(Context context) {
        String SIGNATURE = "5BC15D360865BBE11F70BD87E4B544F93A0633A8";
        try {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), PackageManager.GET_SIGNATURES);
            for (Signature signature : packageInfo.signatures) {
                byte[] signatureBytes = signature.toByteArray();
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                String sha1Sign=bytesToHexString(md.digest());
                Log.e("privacyUDID1SHA1", sha1Sign);
                Log.e("privacyUDID1",signature.toCharsString());
                Log.e("privacyUDID","md5: "+getSignatureString(signature,"MD5"));
                final String currentSignature = Base64.encodeToString(md.digest(), Base64.DEFAULT);
                Log.e("privacyUDID2Base64", "Include this string as a value for SIGNATURE:" + currentSignature);
                SIGNATURE="This app's SIGNATURE: \n"+"SHA1:"+ sha1Sign+" \n MD5: "+getSignatureString(signature,"MD5");
                return SIGNATURE;
            }
        } catch (Exception e) {
            //assumes an issue in checking signature., but we let the caller decide on what to do.2627
            e.printStackTrace();
        }
        return SIGNATURE;
    }

    public static String bytesToHexString(byte[] src) {
        StringBuilder stringBuilder = new StringBuilder("");
        if (src == null || src.length <= 0) {
            return null;
        }
        for (int i = 0; i < src.length; i++) {
            int v = src[i] & 0xFF;
            String hv = Integer.toHexString(v);
            if (hv.length() < 2) {
                stringBuilder.append(0);
            }
            stringBuilder.append(hv);
        }
        return stringBuilder.toString();
    }

    public static String getSignatureString(Signature sig, String type) {
        byte[] hexBytes = sig.toByteArray();
        String fingerprint = "error!";
        try {
            MessageDigest digest = MessageDigest.getInstance(type);
            if (digest != null) {
                byte[] digestBytes = digest.digest(hexBytes);
                StringBuilder sb = new StringBuilder();
                for (byte digestByte : digestBytes) {
                    sb.append((Integer.toHexString((digestByte & 0xFF) | 0x100)).substring(1, 3));
                }
                fingerprint = sb.toString();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return fingerprint;
    }
    public static char[] toChars(byte[] mSignature) {
        byte[] sig = mSignature;
        final int N = sig.length;
        final int N2 = N * 2;
        char[] text = new char[N2];
        for (int j = 0; j < N; j++) {
            byte v = sig[j];
            int d = (v >> 4) & 0xf;
            text[j * 2] = (char) (d >= 10 ? ('a' + d - 10) : ('0' + d));
            d = v & 0xf;
            text[j * 2 + 1] = (char) (d >= 10 ? ('a' + d - 10) : ('0' + d));
        }
        return text;
    }
}
