package com.z9.getuseridtools;

import android.app.Activity;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.ss.android.ugc.getUidNusUQ.ReadFromDataBase.GetAll;
import com.ss.android.ugc.getUidNusUQ.base.BaseUtil;
import com.ss.android.ugc.getUidNusUQ.base.BinderTools;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class MainActivity extends Activity {
    TextView textView;
    public static ArrayList<String> whiteList = new ArrayList<>();
    public static HashMap<String, String> hasDoneList = new HashMap<>();
    public static ArrayList<String> filelist = new ArrayList<>();
    public static ArrayList<String> privacyInfoList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mkdir();
        readIn("/sdcard/bindertest/bindertestDone.txt", hasDoneList);
        readInWhiteList("/sdcard/bindertest/theDone.txt");
        textView = findViewById(R.id.textView);
        Button button1 = findViewById(R.id.button);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //BaseInfo.getBaseInfo(getApplicationContext());
                BaseUtil.runShellCommand("getprop");
                GetAll.getFromTable(getApplicationContext());
                Toast.makeText(getApplicationContext(), "Done", Toast.LENGTH_LONG).show();
            }
        });

        Button button2 = findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String packageName = getPackageName();
                String appSign = BaseUtil.checkAppSignature(getApplicationContext());
                textView.setText("packageName is :" + packageName + "\n" + appSign);
            }
        });

        Button checkSdcard = findViewById(R.id.button3);
        checkSdcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                filelist.clear();
                Log.e("privacyUDID", "Start" + new Date().toString());
                listFile("/sdcard/");
                readPrivacyInfo("/sdcard/bindertest/privacyInfo.txt");
                Log.e("privacyUDID", "Size:" + filelist.size() + " " + privacyInfoList.size());
                for (int i = 0; i < filelist.size(); i++) {
                    readFile(filelist.get(i));
                }
                Log.e("privacyUDID", "End" + new Date().toString());
            }
        });

        Button binderTest = findViewById(R.id.button5);
        binderTest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                writeService();
                invokeAllFunctions();
            }
        });
    }

    public static void readIn(String filePath, HashMap hasDoneList) {
        try {
            if (!new File(filePath).exists())
                return;
            BufferedReader bufr = new BufferedReader(new FileReader(filePath));
            String line = null;
            while ((line = bufr.readLine()) != null) {
                String[] result = line.split(" ");
                hasDoneList.put(result[0], result[1]);
            }
            bufr.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void readInWhiteList(String filePath) {
        try {
            if (!new File(filePath).exists())
                return;
            BufferedReader bufr = new BufferedReader(new FileReader(filePath));
            String line = null;
            while ((line = bufr.readLine()) != null) {
                if (!line.trim().equals("")) {
                    if (!whiteList.contains(line)) {
                        whiteList.add(line);
                    }
                }
            }
            bufr.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void writeService() {
        try {
            File file = new File("/sdcard/bindertest/allFun.txt");
            if (!file.exists()) {
                printAllFunctions();
            }
        } catch (Exception e) {

        }
    }

    public static void printAllFunctions() {
        String[] result = BinderTools.getAllServices();
        for (int i = 0; i < result.length; i++) {
            writeIn("/sdcard/bindertest/allBinderName.txt", result[i] + "\n");
            getAllTheFunctionInOneService(result[i]);
        }
    }


    public static void invokeAllFunctions() {
        String[] result = BinderTools.getAllServices();
        for (int i = 0; i < result.length; i++) {
            try {
                invokeAllTheFunctionInOneService(result[i]);
            } catch (Exception e) {
                e.printStackTrace();
                continue;
            }
        }
    }

    public static void invokeAllTheFunctionInOneService(String serviceName) {
        serviceName = serviceName.trim();
        if (serviceName.trim().equalsIgnoreCase(""))
            return;
        try {
            int code = -1;
            if (hasDoneList.containsKey(serviceName)) {
                code = Integer.valueOf(hasDoneList.get(serviceName));
            } else {
                //hasDoneList.put(serviceName, "-1");
                writeIn("/sdcard/bindertest/bindertestDone.txt", serviceName + " " + "-1" + "\n");
                writeIn("/sdcard/bindertest/hasdoneNow.txt", serviceName + " " + "-1" + "\n");
            }

            IBinder serviceBinder = BinderTools.getTheIbinder(serviceName);
            String interfaceName = BinderTools.getInterfaceName(serviceBinder);
            Class theClass = Class.forName(interfaceName + "$Stub");
            Field[] fields = theClass.getDeclaredFields();


            if (fields.length == 0) {
                //hasDoneList.put(serviceName, "0");
                writeIn("/sdcard/bindertest/bindertestDone.txt", serviceName + " " + "0" + "\n");
                return;
            }

            for (int i = code + 1; i < fields.length; i++) {
                try {
                    Log.e("privacyUDID", fields[i].getName() + " " + serviceName + " " + interfaceName + " " + BinderTools.getCODE(interfaceName, fields[i].getName()) + "  " + BinderTools.getTheInterfaceDescriptor(serviceName));
                    writeIn("/sdcard/bindertest/bindertestDone.txt", serviceName + " " + i + "\n");
                    Thread.sleep(50);
                    String re = runService(serviceName, BinderTools.getCODE(interfaceName, fields[i].getName()));
                    if (re != null && !re.equalsIgnoreCase("")) {
                        writeIn("/sdcard/bindertest/invokeRe.txt", "\n" + fields[i].getName() + " " + serviceName + " " + interfaceName + " " + BinderTools.getCODE(interfaceName, fields[i].getName()) + "  " + BinderTools.getTheInterfaceDescriptor(serviceName) + " result:" + re);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    continue;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String runService(String serviceName, int code) {
        String result = "";
        IBinder iBinder = BinderTools.getTheIbinder(serviceName);
        Parcel parcelData = Parcel.obtain();
        parcelData.writeInterfaceToken(BinderTools.getTheInterfaceDescriptor(serviceName));
        Parcel parcelReply = Parcel.obtain();
        try {
            parcelData.writeInt(0);
            parcelData.writeString("android");
            iBinder.transact(code, parcelData, parcelReply, 0);
            parcelReply.readException();
            result = parcelReply.readString();
            Log.e("privacyUDID", "Result is :" + result);
        } catch (Exception e) {
            e.printStackTrace();
        }
        parcelData.recycle();
        parcelReply.recycle();
        return result;
    }

    public static void getAllTheFunctionInOneService(String serviceName) {
        writeIn("/sdcard/bindertest/allFun.txt", "\n" + serviceName);
        try {
            IBinder serviceBinder = BinderTools.getTheIbinder(serviceName);
            String interfaceName = BinderTools.getInterfaceName(serviceBinder);
            Class theClass = Class.forName(interfaceName + "$Stub");
            Field[] fields = theClass.getDeclaredFields();
            for (int i = 0; i < fields.length; i++) {
                try {
                    Log.e("privacyUDID", interfaceName + " " + fields[i].getName() + " " + BinderTools.getCODE(interfaceName, fields[i].getName()) + " " + serviceName);
                    writeIn("/sdcard/bindertest/allFun.txt", "\n" + fields[i].getName() + " " + serviceName + " " + BinderTools.getCODE(interfaceName, fields[i].getName()) + " " + BinderTools.getTheInterfaceDescriptor(serviceName));
                } catch (Exception e) {
                    e.printStackTrace();
                    continue;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String getNameOfNumInOneService(int serviceNum, String serviceName) {
        try {
            IBinder serviceBinder = BinderTools.getTheIbinder(serviceName);
            String interfaceName = BinderTools.getInterfaceName(serviceBinder);
            Class theClass = Class.forName(interfaceName + "$Stub");
            Field[] fields = theClass.getDeclaredFields();
            for (int i = 0; i < fields.length; i++) {
                try {
                    int theCode = BinderTools.getCODE(interfaceName, fields[i].getName());
                    if (theCode == serviceNum) {
                        return fields[i].getName();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    continue;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "null";
    }


    public static void listFile(String sPath) {
        File file = new File(sPath);
        if (file.exists() && file.isDirectory()) {
            File[] files = file.listFiles();
            if (files == null) {
                return;
            }
            for (int i = 0; i < files.length; i++) {
                listFile(files[i].getAbsolutePath());
            }
        } else {
            if ((!file.getAbsolutePath().contains("com.netease.edu")) && (!file.getAbsolutePath().contains("lark")) && (!file.getAbsolutePath().contains("com.tencent.mm")) && (!file.getAbsolutePath().contains("bindertest")) && (!file.getAbsolutePath().contains("proc/self")) && (!file.getAbsolutePath().contains("proc/thread-self"))) {
                filelist.add(file.getAbsolutePath());
            }
        }
    }

    public static void readPrivacyInfo(String filePath) {
        try {
            if (!new File(filePath).exists())
                return;
            BufferedReader bufr = new BufferedReader(new FileReader(filePath));
            String line = null;
            while ((line = bufr.readLine()) != null) {
                String[] result = line.split(" ");
                int start = line.indexOf(" ");
                line = line.substring(start + 1);
                privacyInfoList.add(line);
            }
            bufr.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void readFile(String filePath) {
        try {
            if (!new File(filePath).exists())
                return;
            if (!new File(filePath).canRead())
                return;
            File file = new File(filePath);
            Log.e("privacyUDID", filePath + " file size: " + (file.length() / 1024 / 1024));
            //writeIn("/sdcard/bindertest/PrivacyInfoResult1111.txt",filePath+" "+file.length()/1024/1024/1024+"\n");

            if (file.length() / 1024 / 1024 > 8) {
                return;
            }


            BufferedReader bufr = new BufferedReader(new FileReader(filePath));
            String line = null;
            while ((line = bufr.readLine()) != null) {
                for (int i = 0; i < privacyInfoList.size(); i++) {
                    if (line.contains(privacyInfoList.get(i))) {
                        writeIn("/sdcard/bindertest/PrivacyInfoResult.txt", filePath + " " + privacyInfoList.get(i) + "\n");
                    }
                }
            }
            bufr.close();
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("privacyUDID", filePath + "---------------");
        }
    }

    public static void writeIn(String file, String content) {
        try {
            FileWriter writer = new FileWriter(file, true);
            writer.write(content);
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void mkdir() {
        File file = new File("/sdcard/bindertest/");
        if (!file.exists()) {
            file.mkdirs();
            //Log.e("privacyUDID","mkdir ok");
        } else {
            //Log.e("privacyUDID","floder is  exit");
        }
    }
}