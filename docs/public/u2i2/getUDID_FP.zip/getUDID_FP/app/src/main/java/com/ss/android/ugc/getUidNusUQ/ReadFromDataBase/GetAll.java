package com.ss.android.ugc.getUidNusUQ.ReadFromDataBase;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.util.Log;

import com.ss.android.ugc.getUidNusUQ.base.BaseUtil;
import com.z9.getuseridtools.MyApplication;

public class GetAll {
    /*settings list secure
    settings list system
    settings list global*/
    public static void getFromTable(Context context) {
        String uriStr = "content://settings/secure";
        BaseUtil.writeIn("/sdcard/bindertest/"+ MyApplication.packageName+".txt", "\n\n"+uriStr);
        Uri uri = Uri.parse(uriStr);
        Cursor cursor = context.getContentResolver().query(uri, null, null, null, null);
        while (cursor.moveToNext()) {
            String str2 = cursor.getString(1);
            String str3 = cursor.getString(2);
            Log.e("privacyUDID", str2 + ": " + str3);
            BaseUtil.writeIn("/sdcard/bindertest/"+ MyApplication.packageName+".txt", "\n"+str2 + ": " + str3);
        }

        uriStr = "content://settings/global";
        BaseUtil.writeIn("/sdcard/bindertest/"+ MyApplication.packageName+".txt", "\n\n"+uriStr);
        uri = Uri.parse(uriStr);
        cursor = context.getContentResolver().query(uri, null, null, null, null);
        while (cursor.moveToNext()) {
            String str2 = cursor.getString(1);
            String str3 = cursor.getString(2);
            Log.e("privacyUDID", str2 + ": " + str3);
            BaseUtil.writeIn("/sdcard/bindertest/"+ MyApplication.packageName+".txt", "\n"+str2 + ": " + str3);
        }

        uriStr = "content://settings/system";
        BaseUtil.writeIn("/sdcard/bindertest/"+ MyApplication.packageName+".txt", "\n\n"+uriStr);
        uri = Uri.parse(uriStr);
        cursor = context.getContentResolver().query(uri, null, null, null, null);
        while (cursor.moveToNext()) {
            String str2 = cursor.getString(1);
            String str3 = cursor.getString(2);
            Log.e("privacyUDID", str2 + ": " + str3);
            BaseUtil.writeIn("/sdcard/bindertest/"+ MyApplication.packageName+".txt", "\n"+str2 + ": " + str3);
        }
    }
}
